"use client";

/**
 * ProductivityChart — Chart 4: Produktivitas Bongkar.
 * Donut / Pie chart with animated legend and inline progress bars.
 * Lazy-loaded via dynamic() in the page.
 */

import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import { produktivitasData } from "@/mock/inbound";

// ─── Custom tooltip ───────────────────────────────────────────────────────────

function ChartTooltip({ active, payload }: any) {
    if (!active || !payload?.length) return null;
    const item = payload[0];
    return (
        <div className="bg-white border border-[#E5E7EB] rounded-xl px-4 py-3 text-xs shadow-lg">
            <p className="font-semibold text-[#111827]">{item.name}</p>
            <p className="font-bold mt-0.5" style={{ color: item.payload.color }}>
                {item.value}%
            </p>
        </div>
    );
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function ProductivityChart() {
    const total = produktivitasData.reduce((s, d) => s + d.value, 0);

    return (
        <div className="bg-white border border-[#E5E7EB] rounded-[18px] p-5 h-[320px] flex flex-col shadow-sm">
            <div className="mb-3">
                <p className="text-sm font-semibold text-[#111827]">Produktivitas Bongkar</p>
                <p className="text-xs text-[#64748B]">Distribusi status penyelesaian bongkar</p>
            </div>

            <div className="flex-1 flex items-center gap-5 min-h-0">
                {/* Donut */}
                <div className="relative w-[140px] h-[140px] shrink-0">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={produktivitasData}
                                cx="50%" cy="50%"
                                innerRadius={48} outerRadius={66}
                                paddingAngle={3}
                                dataKey="value"
                                isAnimationActive
                                animationBegin={200}
                                animationDuration={900}
                            >
                                {produktivitasData.map((entry, i) => (
                                    <Cell key={`cell-${i}`} fill={entry.color} stroke="none" />
                                ))}
                            </Pie>
                            <Tooltip content={<ChartTooltip />} />
                        </PieChart>
                    </ResponsiveContainer>
                    {/* Center label */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                        <p className="text-xl font-bold text-[#111827] leading-none">{total}%</p>
                        <p className="text-[10px] text-[#64748B] mt-0.5">Total</p>
                    </div>
                </div>

                {/* Legend with progress bars */}
                <div className="flex flex-col gap-3 flex-1 min-w-0">
                    {produktivitasData.map((item) => (
                        <div key={item.name} className="flex items-center gap-2.5">
                            <span
                                className="w-2.5 h-2.5 rounded-full shrink-0"
                                style={{ background: item.color }}
                            />
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between mb-1">
                                    <span className="text-xs text-[#64748B] truncate">{item.name}</span>
                                    <span className="text-xs font-bold ml-2 shrink-0" style={{ color: item.color }}>
                                        {item.value}%
                                    </span>
                                </div>
                                <div className="h-1.5 rounded-full bg-[#F1F5F9] overflow-hidden">
                                    <div
                                        className="h-full rounded-full transition-all duration-700"
                                        style={{ width: `${item.value}%`, background: item.color }}
                                    />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
