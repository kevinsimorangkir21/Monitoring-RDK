"use client";

/**
 * StatusFOChart — Chart 1: Klasifikasi Status FO
 * Full-width horizontal bar chart, one bar per status.
 * Lazy-loaded via dynamic() in the page.
 */

import {
    BarChart, Bar,
    XAxis, YAxis, CartesianGrid,
    Tooltip, Cell, ResponsiveContainer, LabelList,
} from "recharts";
import { statusFOData } from "@/mock/outbound";

// ─── Per-status color palette ─────────────────────────────────────────────────

const STATUS_COLORS: Record<string, string> = {
    "Siap Muat": "#F59E0B",
    "Muat Proses": "#2563EB",
    "Muat Selesai": "#16A34A",
    "Berangkat": "#7C3AED",
    "Inap": "#DC2626",
};

// ─── Custom tooltip ───────────────────────────────────────────────────────────

function ChartTooltip({ active, payload, label }: any) {
    if (!active || !payload?.length) return null;
    return (
        <div className="bg-white border border-[#E5E7EB] rounded-xl px-4 py-3 text-xs shadow-lg">
            <p className="font-semibold text-[#111827] mb-1">{label}</p>
            <p className="font-bold" style={{ color: payload[0].fill }}>
                {payload[0].value} FO
            </p>
        </div>
    );
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function StatusFOChart() {
    return (
        <div className="bg-white border border-[#E5E7EB] rounded-[18px] p-5 shadow-sm">
            <div className="mb-4">
                <p className="text-sm font-semibold text-[#111827]">Klasifikasi Status FO</p>
                <p className="text-xs text-[#64748B]">Distribusi jumlah Freight Order berdasarkan status</p>
            </div>

            {/* Full-width bar chart — taller than 2-column charts */}
            <div className="h-[260px]">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                        data={statusFOData}
                        margin={{ top: 16, right: 24, left: -10, bottom: 0 }}
                    >
                        <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                        <XAxis
                            dataKey="status"
                            tick={{ fill: "#64748B", fontSize: 12 }}
                            axisLine={false}
                            tickLine={false}
                        />
                        <YAxis
                            tick={{ fill: "#64748B", fontSize: 11 }}
                            axisLine={false}
                            tickLine={false}
                            width={30}
                        />
                        <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(0,0,0,0.03)" }} />
                        <Bar dataKey="jumlah" name="Jumlah FO" radius={[6, 6, 0, 0]} maxBarSize={60}>
                            <LabelList
                                dataKey="jumlah"
                                position="top"
                                style={{ fill: "#64748B", fontSize: 11, fontWeight: 600 }}
                            />
                            {statusFOData.map((entry) => (
                                <Cell
                                    key={entry.status}
                                    fill={STATUS_COLORS[entry.status] ?? "#64748B"}
                                />
                            ))}
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>

            {/* Legend */}
            <div className="flex flex-wrap gap-3 mt-3">
                {statusFOData.map((item) => (
                    <div key={item.status} className="flex items-center gap-1.5">
                        <span
                            className="w-2.5 h-2.5 rounded-full shrink-0"
                            style={{ background: STATUS_COLORS[item.status] ?? "#64748B" }}
                        />
                        <span className="text-xs text-[#64748B]">{item.status}</span>
                        <span
                            className="text-xs font-bold"
                            style={{ color: STATUS_COLORS[item.status] ?? "#64748B" }}
                        >
                            ({item.jumlah})
                        </span>
                    </div>
                ))}
            </div>
        </div>
    );
}
