"use client";

/**
 * Logo — Sidebar brand mark.
 * In collapsed mode, shows only the icon.
 * In expanded mode, shows icon + app name + subtitle.
 */

import { motion, AnimatePresence } from "framer-motion";

interface LogoProps {
    collapsed: boolean;
}

export default function Logo({ collapsed }: LogoProps) {
    return (
        <div className="h-20 flex items-center gap-3 px-5 border-b border-gray-100 shrink-0 overflow-hidden">
            {/* Icon — always visible */}
            <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center shrink-0 shadow-sm">
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    className="w-5 h-5 text-white"
                    stroke="currentColor"
                    strokeWidth={2.2}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                >
                    <path d="M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z" />
                </svg>
            </div>

            {/* Text — only shown when expanded */}
            <AnimatePresence initial={false}>
                {!collapsed && (
                    <motion.div
                        initial={{ opacity: 0, x: -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -8 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                    >
                        <p className="text-sm font-bold text-gray-900 whitespace-nowrap leading-tight">
                            Monitoring OP
                        </p>
                        <p className="text-[11px] text-gray-400 whitespace-nowrap leading-tight mt-0.5">
                            Operational Monitoring
                        </p>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}
