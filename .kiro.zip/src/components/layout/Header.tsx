"use client";

/**
 * Header — Sticky top bar.
 * Shows: hamburger (mobile), breadcrumb page title, user dropdown.
 * No search, no notification bell per spec.
 */

import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { Menu } from "lucide-react";
import UserDropdown from "./UserDropdown";

// ─── Breadcrumb helpers ───────────────────────────────────────────────────────

/** Convert a URL slug to a display label */
function slugToLabel(slug: string): string {
    return slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

/** Extract breadcrumb segments from pathname, stripping /admin prefix */
function useBreadcrumb(pathname: string) {
    const segments = pathname
        .split("/")
        .filter(Boolean)
        .filter((s) => s !== "admin");

    if (segments.length === 0) return { title: "Dashboard", sub: "Home" };

    const title = slugToLabel(segments[segments.length - 1]);
    const sub = segments.length > 1
        ? segments.slice(0, -1).map(slugToLabel).join(" / ")
        : "Admin";

    return { title, sub };
}

// ─── Props ────────────────────────────────────────────────────────────────────

interface HeaderProps {
    /** Left offset to account for the sidebar width */
    offsetLeft: number;
    onMobileMenuOpen: () => void;
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function Header({ offsetLeft, onMobileMenuOpen }: HeaderProps) {
    const pathname = usePathname();
    const { title, sub } = useBreadcrumb(pathname);

    return (
        <motion.header
            animate={{ paddingLeft: 0 }}
            transition={{ duration: 0.28, ease: [0.4, 0, 0.2, 1] }}
            className="fixed top-0 right-0 z-20 h-20 bg-white border-b border-gray-100 shadow-sm flex items-center justify-between px-6 transition-[left] duration-[280ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
            style={{ left: offsetLeft }}
        >
            {/* Left: mobile menu + page title */}
            <div className="flex items-center gap-4">
                {/* Hamburger — mobile only */}
                <button
                    onClick={onMobileMenuOpen}
                    className="lg:hidden w-9 h-9 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 flex items-center justify-center transition-colors"
                    aria-label="Open navigation menu"
                >
                    <Menu size={18} className="text-gray-600" />
                </button>

                {/* Page title */}
                <div>
                    <h1 className="text-lg font-bold text-gray-900 leading-tight capitalize">
                        {title}
                    </h1>
                    <p className="text-xs text-gray-400 leading-tight">
                        {sub} · Operational Monitoring
                    </p>
                </div>
            </div>

            {/* Right: user dropdown */}
            <UserDropdown />
        </motion.header>
    );
}
