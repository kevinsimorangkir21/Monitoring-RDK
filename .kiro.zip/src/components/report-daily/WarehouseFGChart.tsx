"use client";

/**
 * WarehouseFGChart — Jam Pulang vs Qty Picking
 * ComposedChart: Bar (Qty Picking) + Line (Jam Pulang), dual Y-axis.
 * Lazy-loaded via dynamic() in the page.
 */

import {
    ComposedChart, Bar, Line,
    XAxis, YAxis, CartesianGrid,
    Tooltip, Legend, ResponsiveContainer,
} from "recharts";
import { jamPulangData } from "@/mock/reportDaily";

function ChartTooltip({ active, payload, label }: any) {
    if (!active || !payload?.length) return null;
    return (
        <div className="bg-white border border-[#E5E7EB] rounded-xl px-4 py-3 text-xs shadow-lg min-w-[175px]">
            <p className="font-semibold text-[#111827] mb-2">{label}</p>
            {payload.map((e: any) => (
                <div key={e.name} className="flex justify-between gap-4 mb-0.5">
                    <span style={{ color: e.color }} className="font-medium">{e.name}</span>
                    <span className="font-bold text-[#111827]">
                        {e.name.includes("Jam")
                            ? `${e.value.toFixed(1)}:00`
                            : Number(e.value).toLocaleString("id-ID")}
                    </span>
                </div>
            ))}
        </div>
    );
}

const AXIS = { fill: "#64748B", fontSize: 11 };

export default function WarehouseFGChart() {
    return (
        <div className="bg-white border border-[#E5E7EB] rounded-[18px] p-5 shadow-sm">
            <div className="mb-4">
                <p className="text-sm font-semibold text-[#111827]">Jam Pulang vs Qty Picking</p>
                <p className="text-xs text-[#64748B]">Waktu selesai picking (jam) dibanding total qty picking</p>
            </div>
            <div className="h-[260px]">
                <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart
                        data={jamPulangData}
                        margin={{ top: 4, right: 28, left: -10, bottom: 0 }}
                    >
                        <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                        <XAxis dataKey="tanggal" tick={AXIS} axisLine={false} tickLine={false} />
                        <YAxis
                            yAxisId="left"
                            tick={AXIS}
                            axisLine={false}
                            tickLine={false}
                            width={40}
                            tickFormatter={(v: number) => `${(v / 1000).toFixed(0)}K`}
                        />
                        <YAxis
                            yAxisId="right"
                            orientation="right"
                            tick={AXIS}
                            axisLine={false}
                            tickLine={false}
                            width={30}
                            domain={[14, 20]}
                        />
                        <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(0,0,0,0.03)" }} />
                        <Legend
                            wrapperStyle={{ fontSize: 11, color: "#64748B", paddingTop: 10 }}
                            iconType="circle"
                            iconSize={7}
                        />
                        <Bar
                            yAxisId="left"
                            dataKey="qtyPicking"
                            name="Qty Picking"
                            fill="#16A34A"
                            radius={[5, 5, 0, 0]}
                            maxBarSize={36}
                        />
                        <Line
                            yAxisId="right"
                            dataKey="jamPulang"
                            name="Jam Pulang"
                            stroke="#F59E0B"
                            strokeWidth={2.5}
                            dot={{ fill: "#F59E0B", r: 4, strokeWidth: 0 }}
                            activeDot={{ r: 6 }}
                            type="monotone"
                        />
                    </ComposedChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
}
